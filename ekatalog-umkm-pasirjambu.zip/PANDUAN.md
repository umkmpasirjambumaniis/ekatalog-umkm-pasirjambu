# Panduan E-Katalog UMKM Desa Pasirjambu

Panduan ini dibuat supaya perangkat desa bisa lanjutkan website ini
sendiri, tanpa perlu bisa coding.

## Isi folder ini

- `index.html` — file utama website (tampilan, jangan diedit kalau tidak yakin)
- `umkm-data.js` — **file yang akan sering diedit**, isinya daftar UMKM
- `foto/` — folder untuk menyimpan foto-foto UMKM

---

## BAGIAN 1 — Menaruh Website di Internet (GitHub Pages, gratis)

### Langkah 1: Buat akun GitHub
Buka [github.com](https://github.com) → Sign up → ikuti langkahnya (gratis, cukup email).

### Langkah 2: Buat repository baru
1. Klik tombol hijau **"New"** di halaman utama GitHub
2. Isi nama, misal: `ekatalog-umkm-pasirjambu`
3. Pilih **Public**
4. Centang **"Add a README file"**
5. Klik **Create repository**

### Langkah 3: Upload file website
1. Di halaman repository, klik **Add file → Upload files**
2. Drag & drop `index.html` dan `umkm-data.js`
3. Untuk folder `foto`, upload isinya sekaligus (GitHub otomatis buat foldernya kalau kamu drag folder utuh, atau bisa juga bikin folder dulu dengan cara upload salah satu foto dan ketik `foto/namafile.jpg` di kolom nama saat upload)
4. Scroll ke bawah, klik **Commit changes**

### Langkah 4: Aktifkan GitHub Pages
1. Di repository, klik tab **Settings**
2. Di menu kiri, klik **Pages**
3. Di bagian "Branch", pilih **main** dan folder **/ (root)** → klik **Save**
4. Tunggu 1-2 menit, refresh halaman itu — nanti muncul link seperti:
   `https://namauser.github.io/ekatalog-umkm-pasirjambu/`

Itulah alamat website kamu yang bisa dibagikan ke siapa saja, gratis selamanya.

---

## BAGIAN 2 — Menambah UMKM Baru

Semua data UMKM ada di file **`umkm-data.js`**. Ini cara editnya langsung
dari browser, tanpa install aplikasi apapun:

1. Buka repository di GitHub, klik file `umkm-data.js`
2. Klik ikon pensil (✏️ Edit this file) di kanan atas
3. Cari bagian paling bawah file, ada contoh blok kosong dengan komentar
   `CONTOH BLOK KOSONG UNTUK NAMBAH UMKM BARU`
4. Copy blok itu, tempel di **atas** tanda `];` (tanda kurung siku penutup di akhir daftar)
5. Ganti isinya sesuai UMKM baru, contoh:

```
{
  "id": 61,
  "nama": "Warung Kopi Barokah",
  "pemilik": "Pak Dedi",
  "alamat": "Kp. Cikopak, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
  "dusun": "Dusun 1",
  "jenis": "Kuliner",
  "produk": "Kopi, gorengan, mie instan",
  "foto": "",
  "peta": ""
},
```

**Penting:** setiap blok harus diakhiri tanda koma `,`, kecuali kalau itu
blok paling terakhir sebelum `]`.

6. Scroll ke bawah, klik tombol hijau **Commit changes**
7. Tunggu sekitar 1 menit, website otomatis update — tidak perlu upload ulang apapun

---

## BAGIAN 3 — Menambah Foto

1. Siapkan foto (ukuran lebar sekitar 800px sudah cukup, jangan terlalu besar)
2. Di repository GitHub, masuk ke folder `foto`
3. Klik **Add file → Upload files**, upload foto tersebut
4. Buka `umkm-data.js`, cari UMKM yang mau ditambah fotonya, isi baris `"foto"`:
   ```
   "foto": "foto/nama-file-tadi.jpg"
   ```
5. Commit changes seperti biasa

---

## BAGIAN 4 — Menambah Link Peta

1. Buka lokasi UMKM di Google Maps (dari HP atau laptop)
2. Klik **Bagikan** → **Salin link**
3. Di `umkm-data.js`, tempel link itu ke baris `"peta"`:
   ```
   "peta": "https://maps.app.goo.gl/xxxxxxx"
   ```
4. Commit changes

Untuk peta gabungan (satu peta berisi semua titik UMKM), buat dulu petanya
di [Google My Maps](https://mymaps.google.com), lalu ambil kode embed-nya
dan tempel di `index.html` pada bagian yang ada komentar
`SLOT PETA GABUNGAN` (cari pakai Ctrl+F saat mode edit di GitHub).

---

## Siapa saja yang bisa ikut mengelola?

Tambahkan orang lain (misal ketua UMKM atau staf desa lain) sebagai
kolaborator: **Settings → Collaborators → Add people**, masukkan
username/email GitHub mereka. Mereka lalu bisa ikut edit dengan cara
yang sama seperti di atas.

## Kalau salah edit dan website jadi error

GitHub menyimpan semua riwayat perubahan. Buka tab **"< > Code"** →
klik **"commits"** (ada di dekat tombol Add file) → pilih versi
sebelumnya → **Revert** untuk kembalikan ke versi yang benar.
