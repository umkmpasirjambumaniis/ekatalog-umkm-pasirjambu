/*
  =========================================================
  DATA UMKM DESA PASIRJAMBU
  =========================================================
  Ini daftar semua UMKM yang tampil di website. Untuk NAMBAH
  UMKM BARU, EDIT DATA, atau ISI FOTO/PETA, cukup edit file
  ini saja -- tidak perlu buka file index.html.

  CARA ISI FOTO:
    1. Taruh file foto di folder "foto/" (contoh: foto/nira-fashion.jpg)
    2. Isi baris "foto" dengan path itu, contoh:
       "foto": "foto/nira-fashion.jpg"
    3. Kalau foto dihosting online (Google Drive/Imgur), boleh juga
       taruh link lengkapnya, contoh:
       "foto": "https://i.imgur.com/xxxxx.jpg"
    4. Kalau belum ada foto, biarkan kosong: "foto": ""

  CARA ISI PETA:
    1. Buka lokasi UMKM di Google Maps, klik "Bagikan" > "Salin link"
    2. Tempel link itu ke baris "peta", contoh:
       "peta": "https://maps.app.goo.gl/xxxxxxx"
    3. Kalau belum ada, biarkan kosong: "peta": ""

  CARA NAMBAH UMKM BARU:
    Copy 1 blok dari tanda kurung kurawal { sampai } (termasuk koma
    setelahnya), tempel di akhir daftar (sebelum tanda "]" penutup),
    lalu ganti isinya. Contoh blok kosong siap isi ada di paling
    bawah file ini.

  Jenis usaha yang sudah dikenali sistem (biar warna & ikon otomatis
  sesuai): Perdagangan, Kuliner, Jasa, Kerajinan, Pertenakan,
  "Pertanian atau Perkebunan", Lainnya. Kalau pakai jenis baru di luar
  ini juga tetap tampil, cuma warnanya default.
  =========================================================
*/

const umkmData = [
  {
    "id": 1,
    "nama": "Nira Fashion",
    "pemilik": "Eni",
    "alamat": "Kp. Sukamanah, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Lainnya",
    "produk": "Pakaian, Elektronik, Furnitur, Serba ada",
    "foto": "",
    "peta": ""
  },
  {
    "id": 2,
    "nama": "Warung Teh Sarah",
    "pemilik": "Siti",
    "alamat": "Kp. Cijambu, RT 14/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Makanan dan Jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 3,
    "nama": "Eka Beauty Studio",
    "pemilik": "Eka",
    "alamat": "Kp. Cikopak, RT 13/RW 05, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Jasa",
    "produk": "Salon perawatan, treatment, smoothing, eyelash, nail art",
    "foto": "",
    "peta": ""
  },
  {
    "id": 4,
    "nama": "Warung Bu Iis",
    "pemilik": "Iis",
    "alamat": "Kp. Cikopak, RT 13/RW 05, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Pertanian atau Perkebunan",
    "produk": "Sembako, bensin, jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 5,
    "nama": "Warung Opik",
    "pemilik": "Taufik Hidayat",
    "alamat": "Kp. Cikopak, RT 13/RW 05, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Sembako, ATM mini, pulsa",
    "foto": "",
    "peta": ""
  },
  {
    "id": 6,
    "nama": "Warung Bu Entin",
    "pemilik": "Entin",
    "alamat": "Kp. Cisuren, RT 12/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Perdagangan",
    "produk": "Sembako, bensin",
    "foto": "",
    "peta": ""
  },
  {
    "id": 7,
    "nama": "Waeung Seblak Teh Nina",
    "pemilik": "Nina",
    "alamat": "Kp. Cisuren, RT 12/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Kuliner",
    "produk": "Seblak, Jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 8,
    "nama": "Mi Ayam Pak Adung",
    "pemilik": "Pak Adung",
    "alamat": "Kp. Cisuren, RT 12/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Kuliner",
    "produk": "Kupat tahu, mi ayam, cilok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 9,
    "nama": "Toko sembako Al-Barokah",
    "pemilik": "Eni",
    "alamat": "Kp. Cijambu, RT 12, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Sembako, Parabot, Pakaian",
    "foto": "",
    "peta": ""
  },
  {
    "id": 10,
    "nama": "Warung Teh Rani",
    "pemilik": "Rani Wulansari",
    "alamat": "Kp. Cimahi, RT 11/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Sembako, Jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 11,
    "nama": "Warung Teh Ayi",
    "pemilik": "Ayi",
    "alamat": "Kp. Cimahi, RT 10/RW 03, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Perdagangan",
    "produk": "Sembako, Jajanan, Cilor",
    "foto": "",
    "peta": ""
  },
  {
    "id": 12,
    "nama": "Warung Ibu Susan",
    "pemilik": "Susan",
    "alamat": "Kp. Cimahi, RT 11/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Perdagangan",
    "produk": "Sembako, Jajanan, Seblak, Bakso, Cilok, Karedok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 13,
    "nama": "Warung Teh Nuraidah",
    "pemilik": "NurAidah",
    "alamat": "Kp. Cimahi, RT 11/RW 04, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Kuliner",
    "produk": "Sembako, Jajanan, Mi Jebew, Mi Ayam, Seblak",
    "foto": "",
    "peta": ""
  },
  {
    "id": 14,
    "nama": "BRILINK DESI ANJAENI",
    "pemilik": "DESI ANJAENI",
    "alamat": "Kp. Cijambu, RT 06/RW 07, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Jasa",
    "produk": "Tarik tunai, setor tunai, setor  pinjaman, transfer, top up e wallet.",
    "foto": "",
    "peta": ""
  },
  {
    "id": 15,
    "nama": "Kedai Han Es Kelapa Muda dan Minuman Lainnya",
    "pemilik": "Rudi",
    "alamat": "Kp. Cijambu, RT 6/RW 07, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Kuliner",
    "produk": "Es kelapa, es jeruk, dimsum, Es Teler",
    "foto": "",
    "peta": ""
  },
  {
    "id": 16,
    "nama": "Toko Sayur Ibu Nina",
    "pemilik": "Ibu Nina & Bapak Mahmudin",
    "alamat": "Kp. Cijambu, RT 06, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Buah & sayur",
    "foto": "",
    "peta": ""
  },
  {
    "id": 17,
    "nama": "Pengelolaan Kayu Pak Ipang",
    "pemilik": "Ipang",
    "alamat": "Kp. Cisuren, RT 12, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 3",
    "jenis": "Kerajinan",
    "produk": "Kayu, perahu, mebel",
    "foto": "",
    "peta": ""
  },
  {
    "id": 18,
    "nama": "Warung Nasi Parasmanan Teh Leni",
    "pemilik": "Teh Leni",
    "alamat": "Kp. Sampalan Wetan, RT 03/RW 05, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Kuliner",
    "produk": "Makanan (Teman Nasi)",
    "foto": "",
    "peta": ""
  },
  {
    "id": 19,
    "nama": "Yusuf",
    "pemilik": "Ikan Segar Bapa Yusuf",
    "alamat": "Kp. Sampalan Wetan, RT 03/RW 08, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Pertenakan",
    "produk": "Ikan segar, ikan asin, Ikan nila, emas",
    "foto": "",
    "peta": ""
  },
  {
    "id": 20,
    "nama": "Toko sembako pak bujang",
    "pemilik": "Pak bujang",
    "alamat": "Kp. Citiis RT 09/RW 03, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako",
    "foto": "",
    "peta": ""
  },
  {
    "id": 21,
    "nama": "Warung Dua Putra",
    "pemilik": "Ibu Nurbaeti",
    "alamat": "Kp. Sampalan, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Sembako, Pulsa",
    "foto": "",
    "peta": ""
  },
  {
    "id": 22,
    "nama": "Sawmil",
    "pemilik": "H. tapif",
    "alamat": "Kp. Citiis, RT 03/RW 09, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Kerajinan",
    "produk": "Sawmil & kayu",
    "foto": "",
    "peta": ""
  },
  {
    "id": 23,
    "nama": "Seblak dan Jus Teh Rani",
    "pemilik": "Teh Rani",
    "alamat": "Kp. Sampalan RT 03/08, Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Kuliner",
    "produk": "Seblak, Jus, basreng, dll",
    "foto": "",
    "peta": ""
  },
  {
    "id": 24,
    "nama": "Warung Ibu Juju",
    "pemilik": "Ibu Juju",
    "alamat": "Kp. Cimanggu, RT 1, Desa Pasirjambu",
    "dusun": "Dusun 1",
    "jenis": "Kuliner",
    "produk": "Warung jajanan, snacks",
    "foto": "",
    "peta": ""
  },
  {
    "id": 25,
    "nama": "Warung Ajuy",
    "pemilik": "Ibu Ani",
    "alamat": "Kp. Cimanggu RT 01/RW 01, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Warung, Gas, dan Bensin",
    "foto": "",
    "peta": ""
  },
  {
    "id": 26,
    "nama": "Toko Alat Pancing H. Eman",
    "pemilik": "H. Eman",
    "alamat": "Kp. Cijambu RT 07/RW 02, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Lainnya",
    "produk": "Alat pancing, sembako, pupuk urea",
    "foto": "",
    "peta": ""
  },
  {
    "id": 27,
    "nama": "Toko Grosir Syabil",
    "pemilik": "H. Hasan",
    "alamat": "Kp. Cijambu, RT 06/RW 07, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako",
    "foto": "",
    "peta": ""
  },
  {
    "id": 28,
    "nama": "Warung Teh Resti",
    "pemilik": "Teh Resti",
    "alamat": "Kp. Cijambu RT . 06/RW 07, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Jajanan warung, makanan minuman",
    "foto": "",
    "peta": ""
  },
  {
    "id": 29,
    "nama": "Warung Ibu Eti",
    "pemilik": "Ibu Eti",
    "alamat": "Kp. Cimanggu RT 02/RW 01, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Jajanan warung, makanan dan minuman, pulsa",
    "foto": "",
    "peta": ""
  },
  {
    "id": 30,
    "nama": "Pangkas Rambut Baraya",
    "pemilik": "Bapak Usup Hanapiah",
    "alamat": "Kp. Cijambu RT 08, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Jasa",
    "produk": "Pangkas Rambut",
    "foto": "",
    "peta": ""
  },
  {
    "id": 31,
    "nama": "Daun Pisang Ibu Rini",
    "pemilik": "Ibu Rini",
    "alamat": "Kp. Sampalan, RT 03, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Kerajinan",
    "produk": "Daun Pisang",
    "foto": "",
    "peta": ""
  },
  {
    "id": 32,
    "nama": "Warung Ibu Cueh",
    "pemilik": "Ibu Cueh",
    "alamat": "Kp. Cimanggu, RT 01/RW 01, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Jajanan warung, makanan dan minuman",
    "foto": "",
    "peta": ""
  },
  {
    "id": 33,
    "nama": "Warung Ibu Ana",
    "pemilik": "Ana Rohanah",
    "alamat": "Kp Cijambu, RT 05, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Warung, Makanan dan Minuman, Jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 34,
    "nama": "Toko Sembako Ilham",
    "pemilik": "Ilham",
    "alamat": "Kp. Cijambu, RT 05, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako",
    "foto": "",
    "peta": ""
  },
  {
    "id": 35,
    "nama": "Toko H. Latifah",
    "pemilik": "H. Latifah",
    "alamat": "Kp. Cijambu, RT 05, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako, Makanan dan Minuman, Jajanan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 36,
    "nama": "Pananjung Mas",
    "pemilik": "Pa Aceng",
    "alamat": "Kp. Cimanggu, RT 01, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Pertenakan",
    "produk": "Jual Ikan",
    "foto": "",
    "peta": ""
  },
  {
    "id": 37,
    "nama": "Depot Air Pinang Merah",
    "pemilik": "Ibu Rahmawati",
    "alamat": "Kp. Cimanggu, RT 01/RW01, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Perdagangan",
    "produk": "Isi ulang air galon, sewa ps",
    "foto": "",
    "peta": ""
  },
  {
    "id": 38,
    "nama": "Warung Na’im Frozen",
    "pemilik": "Ucu Annisa",
    "alamat": "Kp. Cijambu RT 04/RW 05, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Frozen Food, bahan seblak, minyak, isi gas, pulsa",
    "foto": "",
    "peta": ""
  },
  {
    "id": 39,
    "nama": "Kolam Renang dan Warung Pa Bubun",
    "pemilik": "Pa Bubun",
    "alamat": "Kp. Cijambu, RT 05, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Kolam renang dan warung",
    "foto": "",
    "peta": ""
  },
  {
    "id": 40,
    "nama": "Warung Pa H. Amirul",
    "pemilik": "Pa H. Amirul",
    "alamat": "Kp. Cijambu RT 08/RW02, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako, makanan minuman, isi ulang air, gas, pom mini bensin",
    "foto": "",
    "peta": ""
  },
  {
    "id": 41,
    "nama": "Lotek Ibu Rohayati",
    "pemilik": "Ibu Rohayati",
    "alamat": "Kp. Cijambu, RT 18, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Kuliner",
    "produk": "Lotek, Karedok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 42,
    "nama": "Warung Serepet Jaer",
    "pemilik": "Ibu Elis",
    "alamat": "Kp. Cijambu RT 08, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 2",
    "jenis": "Perdagangan",
    "produk": "Sembako, Pom Mini Bensin",
    "foto": "",
    "peta": ""
  },
  {
    "id": 43,
    "nama": "Warung",
    "pemilik": "Ibu Halimah",
    "alamat": "Kp. Cikaret, RT 23, Kec. Maniis, Kabupaten PurwakaRT a, Jawa Barat, 41166",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Sembako",
    "foto": "",
    "peta": ""
  },
  {
    "id": 44,
    "nama": "Warung Ibu Isoh",
    "pemilik": "Ibu Isoh",
    "alamat": "Kp. Cikadu, RT 15, Kec. Maniis Kabupaten PurwakaRT a, Jawa Barat, Indonesia",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 45,
    "nama": "Warung & Agen BRILink Pak Hasanudin",
    "pemilik": "Pak Hasanudin",
    "alamat": "Kp. Cikadu, RT 15/RW 05, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 46,
    "nama": "Warung Bu Elis",
    "pemilik": "Bu Elis",
    "alamat": "Kp. Cikadu, RT 23/RW 05, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 47,
    "nama": "Warung Teh Devi",
    "pemilik": "Teh Devi",
    "alamat": "Kp. Cikaret, RT 16/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 48,
    "nama": "Warung Sayur Teh Irma",
    "pemilik": "Teh Irma",
    "alamat": "Kp. Cikaret, RT 16/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat 41166",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Sayur",
    "foto": "",
    "peta": ""
  },
  {
    "id": 49,
    "nama": "Warung Bu Entus",
    "pemilik": "Bu Entus",
    "alamat": "Kp. Cikaret, RT 17/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 50,
    "nama": "Warung Bu Nunung",
    "pemilik": "Bu Nunung",
    "alamat": "Kp. Cikaret, RT 17/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 51,
    "nama": "Warung Bu Tarsih",
    "pemilik": "Bu Tarsih",
    "alamat": "Kp. Cikaret, RT 17/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 52,
    "nama": "Warung Ibu Munah",
    "pemilik": "Ibu Munah",
    "alamat": "Kp. Cikaret, RT 17/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat 41166",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 53,
    "nama": "Warung Bu Tuti",
    "pemilik": "Bu Tuti",
    "alamat": "Kp. Cikaret, RT 19/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 54,
    "nama": "Warung Bu Iyun",
    "pemilik": "Bu Iyun",
    "alamat": "Kp. Cikaret, RT 19/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 55,
    "nama": "Warung Pak RT 19",
    "pemilik": "Pak RT 19",
    "alamat": "Kp. Cikaret, RT 19/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 56,
    "nama": "Warung Ibu Kokoy",
    "pemilik": "Ibu Kokoy",
    "alamat": "Kp. Cikadu, RT 15/RW 05, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat 41166",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 57,
    "nama": "Warung Bu Imad",
    "pemilik": "Bu Imas",
    "alamat": "Kp. Cikadu, RT 23/RW 05, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 58,
    "nama": "Bengkel Bapak Ahmad",
    "pemilik": "Bapak Ahmad",
    "alamat": "Kp. Cikaret, RT 19/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Jasa Servis",
    "foto": "",
    "peta": ""
  },
  {
    "id": 59,
    "nama": "Warung Abidin",
    "pemilik": "Pak Abidin",
    "alamat": "Kp. Cikaret, RT 19/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  },
  {
    "id": 60,
    "nama": "Warung Bu Ikah",
    "pemilik": "Bu Ikah",
    "alamat": "Kp. Cikaret, RT 17/RW 06, Kec. Maniis, Kab. PurwakaRT a, Jawa Barat",
    "dusun": "Dusun 4",
    "jenis": "Perdagangan",
    "produk": "Kebutuhan pokok",
    "foto": "",
    "peta": ""
  }
];

/*
  ---------------------------------------------------------
  CONTOH BLOK KOSONG UNTUK NAMBAH UMKM BARU (copy dari sini)
  ---------------------------------------------------------

  {
    "id": 61,
    "nama": "Nama Usaha Baru",
    "pemilik": "Nama Pemilik",
    "alamat": "Kp. ..., Kec. Maniis, Kabupaten Purwakarta, Jawa Barat",
    "dusun": "Dusun 1",
    "jenis": "Kuliner",
    "produk": "Sebutkan produk/jasa yang ditawarkan",
    "foto": "",
    "peta": ""
  },

*/
